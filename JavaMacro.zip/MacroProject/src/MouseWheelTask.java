import java.awt.Dimension;
import java.awt.Font;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

//==================================================================================================
//	Mouse Click Task Form
//	���콺 Ŭ�� �Ǵ� ������ ���⸦ �ϴ� �۾�
//==================================================================================================
public class MouseWheelTask extends JPanel {
	private JFrame ancestorFrame = null; 
	//==============================================================================================
	//	JComponents Declare
	//==============================================================================================
	
	public String[] textArray = { "1�� ����","2�� ����","3�� ����","4�� ����","5�� ����",
			  					  "6�� ����","7�� ����","8�� ����","9�� ����","10�� ����"};
	private JRadioButton isVar = new JRadioButton();
	private JRadioButton isCon = new JRadioButton();
	private JComboBox<String> varBox = new JComboBox<String>(textArray);
	private ButtonGroup varBG = new ButtonGroup();
	private JTextField wheelCount = new JTextField(5); 
	private JButton okButton = new JButton("�߰�");
	private JLabel text = new JLabel("���콺 ����");
	private JLabel text2 = new JLabel("��ŭ ����");
	private JLabel text3 = new JLabel("���� : UP / ��� : DOWN");
	private JLabel sumary = new JLabel("���콺 �� �۾� �߰�");
	
	//==============================================================================================
	//	CONSTRUCTOR
	//==============================================================================================
	public MouseWheelTask(JFrame ancestorFrame) {
		//==========================================================================================
		//	Layout Setting
		//==========================================================================================
		setLayout(null);
		setPreferredSize(new Dimension(320,105));
		this.ancestorFrame = ancestorFrame;
		
		//==========================================================================================
		//	Adding Components
		//==========================================================================================
		add(wheelCount);	add(okButton);		add(sumary);		add(varBox);		add(text);
		add(isVar);			add(isCon);			varBG.add(isVar);	varBG.add(isCon);	add(text2);
		add(text3);
		
		//==========================================================================================
		//	Component Location & Size Setting
		//==========================================================================================
		text.setBounds(5,45,100,30);
		text2.setBounds(180,45,100,30);
		isCon.setBounds(75,35,20,20);
		wheelCount.setBounds(95,35,80,20);
		isVar.setBounds(75,60,20,20);
		varBox.setBounds(95,60,80,20);
		okButton.setBounds(250,45,60,30);
		sumary.setBounds(5,0,285,30);
		text3.setBounds(180, 85, 150, 20);
		text3.setFont(new Font("����",Font.PLAIN,11));
		
		
		//==========================================================================================
		//	Adding Listener
		//==========================================================================================
		isVar.addItemListener(new MyMouseWheelItemListener());
		isCon.addItemListener(new MyMouseWheelItemListener());
		okButton.addActionListener(new MyMouseClickActionListener());
		
		//==========================================================================================
		//	Initializing
		//==========================================================================================
		isCon.setSelected(true);
		wheelCount.setText("0");
	}
	
	//==============================================================================================
	//	My Item Listener
	//==============================================================================================
	class MyMouseWheelItemListener implements ItemListener{
		public void itemStateChanged(ItemEvent event) {
			if (event.getSource().equals(isVar)) {
				wheelCount.setText("0");
				wheelCount.setEnabled(false);
				varBox.setEnabled(true);
			} else {
				wheelCount.setEnabled(true);
				varBox.setSelectedIndex(0);
				varBox.setEnabled(false);
			}
		}
	}
	
	//==============================================================================================
	//	Ok Button Listener
	//==============================================================================================
	class MyMouseClickActionListener implements ActionListener{
		public void actionPerformed(ActionEvent event) {
			ancestorFrame.dispose();
			
			try {
				Robot robot = new Robot();
				robot.delay(1000);
				robot.mouseMove(500, 500);
				robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
				robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
				robot.mouseWheel(Integer.parseInt(wheelCount.getText()));
				robot.delay(1000);
				for (int i = 0; i< Integer.parseInt(wheelCount.getText()) ; i++) {
					robot.mouseWheel(-1);
					robot.delay(100);
				}
			} catch( Exception e) {
				
			}
		}
	}
	
	
}

